public class BatTest {
    public static void main(String[] args){
        Bat bat = new Bat(300);
        bat.attackTown();
        bat.attackTown();
        bat.attackTown();
        bat.eatHuman();
        bat.eatHuman();
        bat.fly();
        bat.fly();
        bat.displayEnergy();
    }
}
