public class GorrilaTest {
    public static void main(String[] args){
        Gorrilla monkey = new Gorrilla(100);
        monkey.displayEnergy();
        monkey.throwSomething();
        monkey.throwSomething();
        monkey.throwSomething();
        monkey.climb();
        monkey.displayEnergy();
    }
}
