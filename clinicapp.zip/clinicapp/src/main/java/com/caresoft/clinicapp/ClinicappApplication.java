package com.caresoft.clinicapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClinicappApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClinicappApplication.class, args);
	}

}
