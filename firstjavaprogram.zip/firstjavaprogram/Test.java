public class Test {
    public static void main(String[] args) {
        System.out.println("My name is Eduardo Diaz");
        System.out.println("I am 22 years old");
        System.out.println("My hoemtown is Saint Paul, MN");
    }
}