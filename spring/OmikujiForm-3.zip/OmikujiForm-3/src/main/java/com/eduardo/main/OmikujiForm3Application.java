package com.eduardo.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OmikujiForm3Application {

	public static void main(String[] args) {
		SpringApplication.run(OmikujiForm3Application.class, args);
	}

}
