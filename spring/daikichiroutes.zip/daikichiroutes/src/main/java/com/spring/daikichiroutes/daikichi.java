package com.spring.daikichiroutes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class daikichi {

	public static void main(String[] args) {
		SpringApplication.run(daikichi.class, args);
	}
}